# Veridica LaTeX Starter Pack
This template is optimized for submissions to **Veridica: Journal of Multidisciplinary Research**.

## How to use:
1. **Overleaf**: Upload this entire ZIP file to [Overleaf](https://www.overleaf.com) via "New Project" -> "Upload Project".
2. **Local Compilation**: Run `pdflatex main.tex`, `bibtex main`, `pdflatex main.tex` twice.
3. Ensure all author details remain anonymized until final acceptance for double-blind peer review.
